package com.example.aviva_tasman_agri

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
