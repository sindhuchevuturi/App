import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../domain/state/textfield_state.dart';
import '../helpers/app_colors.dart';
import '../helpers/app_text_style.dart';

class CommonTextField extends StatefulWidget {
  final String hintText;
  final TextEditingController? controller;
  final bool obscure;
  final TextInputType type;
  final bool padding;
  final String? title;
  final bool isTitle;
  final void Function(String)? onSubmit;
  const CommonTextField({
    required this.hintText,
    required this.obscure,
    required this.type,
    required this.isTitle,
    this.controller,
    this.title,
    this.onSubmit,
    required this.padding,
    super.key,
  });

  @override
  State<CommonTextField> createState() => _CommonTextFieldState();
}

class _CommonTextFieldState extends State<CommonTextField> {
  TextFieldState textFieldState = Get.put(TextFieldState());
  @override
  Widget build(BuildContext context) {
    return widget.isTitle
        ? Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.title ?? "",
                style: AppTextStyle.font14SemiBold,
              ),
              SizedBox(height: 12.h),
              Obx(
                () => TextField(
                  obscureText: textFieldState.obscure.value,
                  keyboardType: widget.type,
                  style: AppTextStyle.font14,
                  decoration: InputDecoration(
                    isDense: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.r),
                      borderSide: BorderSide(
                        color: AppColors.blackColor.withOpacity(0.5),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.r),
                      borderSide: BorderSide(
                        color: AppColors.blackColor.withOpacity(0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.r),
                      borderSide: const BorderSide(
                        color: AppColors.primaryColor,
                      ),
                    ),
                    hintText: widget.hintText,
                    suffixIcon: widget.obscure
                        ? GestureDetector(
                            onTap: () => textFieldState.changer(),
                            child: textFieldState.obscure.value
                                ? const Icon(
                                    Icons.visibility_off_outlined,
                                    color: AppColors.primaryColor,
                                  )
                                : const Icon(
                                    Icons.visibility_outlined,
                                    color: AppColors.primaryColor,
                                  ),
                          )
                        : const Text(""),
                    hintStyle: AppTextStyle.font14.copyWith(
                      color: AppColors.blackColor.withOpacity(0.5),
                    ),
                  ),
                  onSubmitted: widget.onSubmit,
                ),
              ),
            ],
          ).paddingSymmetric(
            horizontal: widget.padding ? 12.h : 0,
            vertical: widget.padding ? 8.h : 0,
          )
        : Obx(
            () => TextField(
              obscureText: textFieldState.obscure.value,
              keyboardType: widget.type,
              style: AppTextStyle.font14.copyWith(
                color: AppColors.blackColor.withOpacity(0.5),
              ),
              decoration: InputDecoration(
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.r),
                  borderSide: BorderSide(
                    color: AppColors.blackColor.withOpacity(0.5),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.r),
                  borderSide: BorderSide(
                    color: AppColors.blackColor.withOpacity(0.5),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.r),
                  borderSide: const BorderSide(
                    color: AppColors.primaryColor,
                  ),
                ),
                hintText: widget.hintText,
                suffixIcon: widget.obscure
                    ? GestureDetector(
                        onTap: () => textFieldState.changer(),
                        child: textFieldState.obscure.value
                            ? const Icon(
                                Icons.visibility_off_outlined,
                                color: AppColors.primaryColor,
                              )
                            : const Icon(
                                Icons.visibility_outlined,
                                color: AppColors.primaryColor,
                              ),
                      )
                    : const Text(""),
                hintStyle: AppTextStyle.font14.copyWith(
                  color: AppColors.blackColor.withOpacity(0.5),
                ),
              ),
              onSubmitted: widget.onSubmit,
            ).paddingSymmetric(
              horizontal: widget.padding ? 12.h : 0,
              vertical: widget.padding ? 8.h : 0,
            ),
          );
  }
}
