import 'package:flutter/material.dart';
import 'package:get/get.dart';

PreferredSizeWidget commonAppBar(
  BuildContext context,
  List<Widget> actions,
) {
  return AppBar(
    actions: actions,
    leading: GestureDetector(
      onTap: () => Get.back(),
      child: const Icon(
        Icons.arrow_back,
      ),
    ),
  );
}
