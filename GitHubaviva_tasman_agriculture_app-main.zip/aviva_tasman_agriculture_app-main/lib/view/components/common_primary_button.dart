import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../helpers/app_colors.dart';

class CommonPrimaryButton extends StatelessWidget {
  final double? phori;
  final double? pverti;
  final double height;
  final double? width;
  final String title;
  final Color mainColor;
  final double? radius;
  final Widget? children;
  final Color? borderColor;
  final TextStyle textStyle;
  final void Function()? ontap;
  const CommonPrimaryButton({
    required this.title,
    required this.height,
    required this.mainColor,
    required this.textStyle,
    this.children,
    this.width,
    this.phori,
    this.pverti,
    this.radius,
    this.ontap,
    this.borderColor,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
          horizontal: phori ?? 12.w, vertical: pverti ?? 8.h),
      child: GestureDetector(
        onTap: ontap,
        child: Container(
          height: height,
          width: width ?? double.infinity,
          decoration: BoxDecoration(
            color: mainColor,
            border: Border.all(
              width: 0,
              color: borderColor ?? AppColors.transColor,
            ),
            borderRadius: BorderRadius.circular(radius ?? 8.r),
          ),
          child: children ??
              Center(
                child: Text(
                  title,
                  style: textStyle,
                ),
              ),
        ),
      ),
    );
  }
}
