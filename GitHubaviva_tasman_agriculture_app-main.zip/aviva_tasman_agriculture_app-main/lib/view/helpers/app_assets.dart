import 'app_variables.dart';

class AppAssets {
  static final mainLogo = "${image}mainLogo.jpeg";
  static final login = "${image}login.png";
  static final signup = "${image}signup.png";
  static final forgotpassword = "${image}forgotpassword.png";
  static final homeSvg = "${svg}homeSvg.svg";
  static final heartSvg = "${svg}heartSvg.svg";
  static final addSvg = "${svg}addSvg.svg";
  static final cartSvg = "${svg}cartSvg.svg";
  static final profileSvg = "${svg}profileSvg.svg";
  static final starSvg = "${svg}starSvg.svg";
  static final doneSvg = "${svg}doneSvg.svg";
  static final heartfullSvg = "${svg}heartfullSvg.svg";
  static final cameraSvg = "${svg}cameraSvg.svg";
  static final editSvg = "${svg}editSvg.svg";
  static final orderSvg = "${svg}orderSvg.svg";
  static final notificationSvg = "${svg}notificationSvg.svg";
  static final logoutSvg = "${svg}logoutSvg.svg";
  static final contactusSvg = "${svg}contactusSvg.svg";
  static final deleteSvg = "${svg}deleteSvg.svg";
  static final boxSvg = "${svg}boxSvg.svg";
  static final infoSvg = "${svg}infoSvg.svg";
  static final settingSvg = "${svg}settingSvg.svg";
  static final languageSvg = "${svg}languageSvg.svg";
  static final currencySvg = "${svg}currencySvg.svg";
  static const profileDemoImage =
      "https://i.imgur.com/vl7XBh6.jpg";
  static const productDemoImage =
      "https://i.imgur.com/jjDzqOx.png";
}
