import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppTextStyle {
  // Regular
  static final font8 = TextStyle(
    fontSize: 8.sp,
    fontWeight: FontWeight.w400,
  );
  static final font12 = TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.w400,
  );
  static final font14 = TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.w400,
  );
  static final font16 = TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeight.w400,
  );
  static final font18 = TextStyle(
    fontSize: 18.sp,
    fontWeight: FontWeight.w400,
  );
  static final font20 = TextStyle(
    fontSize: 20.sp,
    fontWeight: FontWeight.w400,
  );
  static final font22 = TextStyle(
    fontSize: 22.sp,
    fontWeight: FontWeight.w400,
  );
  static final font24 = TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeight.w400,
  );
  static final font26 = TextStyle(
    fontSize: 26.sp,
    fontWeight: FontWeight.w400,
  );
  static final font28 = TextStyle(
    fontSize: 28.sp,
    fontWeight: FontWeight.w400,
  );
  static final font30 = TextStyle(
    fontSize: 30.sp,
    fontWeight: FontWeight.w400,
  );
  static final font40 = TextStyle(
    fontSize: 40.sp,
    fontWeight: FontWeight.w400,
  );
  static final font46 = TextStyle(
    fontSize: 46.sp,
    fontWeight: FontWeight.w400,
  );
  static final font48 = TextStyle(
    fontSize: 48.sp,
    fontWeight: FontWeight.w400,
  );
  static final font54 = TextStyle(
    fontSize: 54.sp,
    fontWeight: FontWeight.w400,
  );
  static final font58 = TextStyle(
    fontSize: 58.sp,
    fontWeight: FontWeight.w400,
  );
  static final font64 = TextStyle(
    fontSize: 64.sp,
    fontWeight: FontWeight.w400,
  );
  // Semi-Bold
  static final font12SemiBold = TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.w600,
  );
  static final font14SemiBold = TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.w600,
  );
  static final font16SemiBold = TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeight.w600,
  );
  static final font18SemiBold = TextStyle(
    fontSize: 18.sp,
    fontWeight: FontWeight.w600,
  );
  static final font20SemiBold = TextStyle(
    fontSize: 20.sp,
    fontWeight: FontWeight.w600,
  );
  static final font22SemiBold = TextStyle(
    fontSize: 22.sp,
    fontWeight: FontWeight.w600,
  );
  static final font24SemiBold = TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeight.w600,
  );
  static final font26SemiBold = TextStyle(
    fontSize: 26.sp,
    fontWeight: FontWeight.w600,
  );
  static final font28SemiBold = TextStyle(
    fontSize: 28.sp,
    fontWeight: FontWeight.w600,
  );
  static final font30SemiBold = TextStyle(
    fontSize: 30.sp,
    fontWeight: FontWeight.w600,
  );
  static final font40SemiBold = TextStyle(
    fontSize: 40.sp,
    fontWeight: FontWeight.w600,
  );
  static final font46SemiBold = TextStyle(
    fontSize: 46.sp,
    fontWeight: FontWeight.w600,
  );
  static final font48SemiBold = TextStyle(
    fontSize: 48.sp,
    fontWeight: FontWeight.w600,
  );
  static final font54SemiBold = TextStyle(
    fontSize: 54.sp,
    fontWeight: FontWeight.w600,
  );
  static final font58SemiBold = TextStyle(
    fontSize: 58.sp,
    fontWeight: FontWeight.w600,
  );
  static final font64SemiBold = TextStyle(
    fontSize: 64.sp,
    fontWeight: FontWeight.w600,
  );
  // Bold
  static final font12Bold = TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.bold,
  );
  static final font14Bold = TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.bold,
  );
  static final font16Bold = TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeight.bold,
  );
  static final font18Bold = TextStyle(
    fontSize: 18.sp,
    fontWeight: FontWeight.bold,
  );
  static final font20Bold = TextStyle(
    fontSize: 20.sp,
    fontWeight: FontWeight.bold,
  );
  static final font22Bold = TextStyle(
    fontSize: 22.sp,
    fontWeight: FontWeight.bold,
  );
  static final font24Bold = TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeight.bold,
  );
  static final font26Bold = TextStyle(
    fontSize: 26.sp,
    fontWeight: FontWeight.bold,
  );
  static final font28Bold = TextStyle(
    fontSize: 28.sp,
    fontWeight: FontWeight.bold,
  );
  static final font30Bold = TextStyle(
    fontSize: 30.sp,
    fontWeight: FontWeight.bold,
  );
  static final font38Bold = TextStyle(
    fontSize: 38.sp,
    fontWeight: FontWeight.bold,
  );
  static final font40Bold = TextStyle(
    fontSize: 40.sp,
    fontWeight: FontWeight.bold,
  );
  static final font46Bold = TextStyle(
    fontSize: 46.sp,
    fontWeight: FontWeight.bold,
  );
  static final font48Bold = TextStyle(
    fontSize: 48.sp,
    fontWeight: FontWeight.bold,
  );
  static final font54Bold = TextStyle(
    fontSize: 54.sp,
    fontWeight: FontWeight.bold,
  );
  static final font58Bold = TextStyle(
    fontSize: 58.sp,
    fontWeight: FontWeight.bold,
  );
  static final font64Bold = TextStyle(
    fontSize: 64.sp,
    fontWeight: FontWeight.bold,
  );
}
