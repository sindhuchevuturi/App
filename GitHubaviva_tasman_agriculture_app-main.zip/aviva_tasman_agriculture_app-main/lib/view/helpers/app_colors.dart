import 'package:flutter/material.dart';

class AppColors {
  static const MaterialColor primaryColor = MaterialColor(
    0xFF01579B, // Replace this with the Shade 900 blue value
    <int, Color>{
      50: Color(0xFFE1F5FE),
      100: Color(0xFFB3E0FE),
      200: Color(0xFF81D4FA),
      300: Color(0xFF4FC3F7),
      400: Color(0xFF29B6F6),
      500: Color(0xFF03A9F4),
      600: Color(0xFF039BE5),
      700: Color(0xFF0288D1),
      800: Color(0xFF0277BD),
      900: Color(0xFF01579B), // This is Shade 900 blue
    },
  );
  static const whiteColor = Colors.white;
  static const redColor = Colors.red;
  static const greyColor = Colors.grey;
  static const blackColor = Colors.black;
  static const yellowColor = Colors.yellow;
  static const transColor = Colors.transparent;
}
