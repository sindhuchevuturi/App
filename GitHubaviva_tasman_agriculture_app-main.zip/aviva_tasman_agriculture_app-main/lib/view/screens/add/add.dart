// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';

import '../../components/common_primary_button.dart';
import '../../components/common_textfield.dart';
import '../../helpers/app_assets.dart';
import '../../helpers/app_colors.dart';
import '../../helpers/app_text_style.dart';

class AddScreen extends StatefulWidget {
  const AddScreen({super.key});

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 300.h,
              width: double.infinity,
              color: AppColors.greyColor.withOpacity(0.2),
              child: Center(
                child: SvgPicture.asset(
                  AppAssets.cameraSvg,
                  height: 80.h,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
            SizedBox(height: 20.h),
            const CommonTextField(
              hintText: "Enter Product Name",
              obscure: false,
              type: TextInputType.name,
              isTitle: true,
              padding: true,
              title: "Product Name",
            ),
            const CommonTextField(
              hintText: "Enter Description",
              obscure: false,
              type: TextInputType.name,
              isTitle: true,
              padding: true,
              title: "Description",
            ),
            const CommonTextField(
              hintText: "Enter Price",
              obscure: false,
              type: TextInputType.number,
              isTitle: true,
              padding: true,
              title: "Price",
            ),
            SizedBox(height: 20.h),
            CommonPrimaryButton(
              title: "Upload Now",
              height: 55.h,
              radius: 20.r,
              mainColor: AppColors.primaryColor,
              textStyle: AppTextStyle.font16SemiBold.copyWith(
                color: AppColors.whiteColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
