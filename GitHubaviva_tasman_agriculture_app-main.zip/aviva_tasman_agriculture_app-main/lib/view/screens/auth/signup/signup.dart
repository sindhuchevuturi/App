import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../config/routes/routes.dart';
import '../../../components/common_appbar.dart';
import '../../../components/common_primary_button.dart';
import '../../../components/common_textfield.dart';
import '../../../helpers/app_assets.dart';
import '../../../helpers/app_colors.dart';
import '../../../helpers/app_text_style.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.asset(AppAssets.signup, height: 200.h),
            Text(
              "Sign Up",
              style: AppTextStyle.font24SemiBold,
            ),
            SizedBox(height: 8.h),
            const CommonTextField(
              hintText: "Enter Your Name",
              obscure: false,
              type: TextInputType.name,
              isTitle: true,
              padding: true,
              title: "Name",
            ),
            const CommonTextField(
              hintText: "example@gmail.com",
              obscure: false,
              type: TextInputType.emailAddress,
              isTitle: true,
              padding: true,
              title: "Email",
            ),
            const CommonTextField(
              hintText: "••••••••",
              obscure: true,
              type: TextInputType.visiblePassword,
              isTitle: true,
              padding: true,
              title: "Password",
            ),
            SizedBox(height: 20.h),
            CommonPrimaryButton(
              title: "Sign Up Now",
              height: 55.h,
              radius: 20.r,
              mainColor: AppColors.primaryColor,
              textStyle: AppTextStyle.font14SemiBold.copyWith(
                color: AppColors.whiteColor,
              ),
            ),
            SizedBox(height: 12.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Already have an account?",
                  style: AppTextStyle.font12SemiBold,
                ),
                SizedBox(width: 8.w),
                GestureDetector(
                  onTap: () => Get.toNamed(routeLoginScreen),
                  child: Text(
                    "Login",
                    style: AppTextStyle.font12SemiBold.copyWith(
                      color: AppColors.primaryColor,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
