// ignore_for_file: deprecated_member_use

import 'package:aviva_tasman_agri/config/routes/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../components/common_primary_button.dart';
import '../../../components/common_textfield.dart';
import '../../../helpers/app_assets.dart';
import '../../../helpers/app_colors.dart';
import '../../../helpers/app_text_style.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      child: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Image.asset(AppAssets.login, height: 250.h),
                Text(
                  "Welcome Back !",
                  style: AppTextStyle.font24SemiBold,
                ),
                SizedBox(height: 8.h),
                const CommonTextField(
                  hintText: "example@gmail.com",
                  obscure: false,
                  type: TextInputType.emailAddress,
                  isTitle: true,
                  padding: true,
                  title: "Email",
                ),
                const CommonTextField(
                  hintText: "••••••••",
                  obscure: true,
                  type: TextInputType.visiblePassword,
                  isTitle: true,
                  padding: true,
                  title: "Password",
                ),
                SizedBox(height: 12.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () => Get.toNamed(routeResetPasswordScreen),
                      child: Text(
                        "Forgot Password ?",
                        style: AppTextStyle.font12SemiBold,
                      ),
                    ),
                  ],
                ).paddingSymmetric(horizontal: 12.w),
                SizedBox(height: 20.h),
                CommonPrimaryButton(
                  ontap: () => Get.toNamed(routeBottomNavScreen),
                  title: "Login Now",
                  height: 55.h,
                  radius: 20.r,
                  mainColor: AppColors.primaryColor,
                  textStyle: AppTextStyle.font14SemiBold.copyWith(
                    color: AppColors.whiteColor,
                  ),
                ),
                SizedBox(height: 12.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Don't have an account?",
                      style: AppTextStyle.font12SemiBold,
                    ),
                    SizedBox(width: 8.w),
                    GestureDetector(
                      onTap: () => Get.toNamed(routeSignupScreen),
                      child: Text(
                        "Sign Up",
                        style: AppTextStyle.font12SemiBold.copyWith(
                          color: AppColors.primaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      onWillPop: () async {
        return false;
      },
    );
  }
}
