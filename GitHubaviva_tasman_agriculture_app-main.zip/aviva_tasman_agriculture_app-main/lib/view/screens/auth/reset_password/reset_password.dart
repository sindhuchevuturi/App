import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../components/common_appbar.dart';
import '../../../components/common_primary_button.dart';
import '../../../components/common_textfield.dart';
import '../../../helpers/app_assets.dart';
import '../../../helpers/app_colors.dart';
import '../../../helpers/app_text_style.dart';

class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({super.key});

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.asset(AppAssets.forgotpassword, height: 250.h),
            SizedBox(height: 20.h),
            Text(
              "Forgot Password",
              style: AppTextStyle.font24SemiBold,
            ),
            SizedBox(height: 8.h),
            const CommonTextField(
              hintText: "example@gmail.com",
              obscure: false,
              type: TextInputType.emailAddress,
              isTitle: true,
              padding: true,
              title: "Email",
            ),
            SizedBox(height: 20.h),
            CommonPrimaryButton(
              title: "Send Link",
              height: 55.h,
              radius: 20.r,
              mainColor: AppColors.primaryColor,
              textStyle: AppTextStyle.font14SemiBold.copyWith(
                color: AppColors.whiteColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
