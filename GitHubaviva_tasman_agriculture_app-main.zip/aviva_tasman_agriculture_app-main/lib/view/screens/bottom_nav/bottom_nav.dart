// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';

import '../../../domain/state/bottom_nav_state.dart';
import '../../helpers/app_assets.dart';
import '../../helpers/app_colors.dart';

class BottomNavScreen extends StatefulWidget {
  const BottomNavScreen({super.key});

  @override
  State<BottomNavScreen> createState() => _BottomNavScreenState();
}

class _BottomNavScreenState extends State<BottomNavScreen> {
  var state = Get.put(BottomNavState());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(
        () => state.pages[state.index.value],
      ),
      bottomNavigationBar: Obx(
        () => SalomonBottomBar(
          currentIndex: state.index.value,
          onTap: (e) => state.changePageIndex(e),
          selectedItemColor: AppColors.primaryColor,
          unselectedItemColor: AppColors.greyColor,
          items: [
            SalomonBottomBarItem(
              icon: SvgPicture.asset(
                AppAssets.homeSvg,
                color: state.index.value == 0
                    ? AppColors.primaryColor
                    : AppColors.blackColor,
              ),
              title: const Text("Home"),
            ),
            // SalomonBottomBarItem(
            //   icon: SvgPicture.asset(
            //     AppAssets.heartSvg,
            //     color: state.index.value == 1
            //         ? AppColors.primaryColor
            //         : AppColors.blackColor,
            //   ),
            //   title: const Text("Favourite"),
            // ),
            SalomonBottomBarItem(
              icon: SvgPicture.asset(
                AppAssets.addSvg,
                color: state.index.value == 1
                    ? AppColors.primaryColor
                    : AppColors.blackColor,
              ),
              title: const Text("Upload"),
            ),
            SalomonBottomBarItem(
              icon: SvgPicture.asset(
                AppAssets.cartSvg,
                color: state.index.value == 2
                    ? AppColors.primaryColor
                    : AppColors.blackColor,
              ),
              title: const Text("Cart"),
            ),
            SalomonBottomBarItem(
              icon: SvgPicture.asset(
                AppAssets.profileSvg,
                color: state.index.value == 3
                    ? AppColors.primaryColor
                    : AppColors.blackColor,
              ),
              title: const Text("Me"),
            ),
          ],
        ),
      ),
    );
  }
}
