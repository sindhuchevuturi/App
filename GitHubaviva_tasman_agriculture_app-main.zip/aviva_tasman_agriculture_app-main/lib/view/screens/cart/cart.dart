import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'CartItem.dart';
import '../../../config/utility/bottom_sheet.dart';
import '../../../config/utility/dialog.dart';
import '../../components/common_primary_button.dart';
import '../../components/common_textfield.dart';
import '../../helpers/app_assets.dart';
import '../../helpers/app_colors.dart';
import '../../helpers/app_text_style.dart';
import '../../widgets/cart_const.dart';
import 'cartController.dart';

class CartScreen extends StatelessWidget {
  final CartController cartController = Get.put(CartController());
  double calculateTotalAmount() {
    double totalPrice = 0.0;
    for (CartItem item in cartController.cartItems) {
      totalPrice += item.quantity * item.price;
    }
    return totalPrice;
  }

//class CartScreen extends StatefulWidget {
  //const CartScreen({super.key});

 // @override
 // State<CartScreen> createState() => _CartScreenState();
//}

//class _CartScreenState extends State<CartScreen>  {
  //List<CartItem> cartItems = []; // Replace CartItem with your actual data model

 // double calculateTotalAmount() {
   // double totalPrice = 0.0;

    // Iterate through your cart items and calculate the total
  //  for (CartItem item in cartItems) {
  //    totalPrice += item.quantity * item.price;
  //  }

  //  return totalPrice;
 // }

  @override
  @override
  Widget build(BuildContext context) {
    final CartController cartController = Get.find<CartController>();


    print("Cart Items in Build: ${cartController.cartItems}");
    print("Total Amount: ${calculateTotalAmount()}");

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 40.h),
              Text("My", style: AppTextStyle.font28),
              Text("Cart", style: AppTextStyle.font28SemiBold),
              SizedBox(height: 20.h),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: cartController.cartItems.length,
                itemBuilder: (context, index) {
                  // You may want to pass the specific cart item to CartConst here
                  return Obx(() => CartConst(cartItem: cartController.cartItems[index]));
                },
              ),
            ],
          ).paddingSymmetric(horizontal: 20.w),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80.h,
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.primaryColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20.r),
            topRight: Radius.circular(20.r),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Total",
                  style: AppTextStyle.font14.copyWith(
                    color: AppColors.whiteColor,
                  ),
                ),
                Text(
                  "₱ ${calculateTotalAmount().toStringAsFixed(2)} PHP",
                  style: AppTextStyle.font24SemiBold.copyWith(
                    color: AppColors.whiteColor,
                  ),
                ),
              ],
            ),
            GestureDetector(
              onTap: () => customBottomSheet(
                context,
                Column(
                  children: [
                    const CommonTextField(
                      hintText: "SC",
                      obscure: false,
                      type: TextInputType.name,
                      isTitle: true,
                      padding: false,
                      title: "Your Name",
                    ),
                    SizedBox(height: 12.h),
                    const CommonTextField(
                      hintText: "Enter Address Line 1",
                      obscure: false,
                      type: TextInputType.name,
                      isTitle: true,
                      padding: false,
                      title: "Address Line 1",
                    ),
                    SizedBox(height: 12.h),
                    const CommonTextField(
                      hintText: "Enter Your Address Line 2",
                      obscure: false,
                      type: TextInputType.name,
                      isTitle: true,
                      padding: false,
                      title: "Address Line 2",
                    ),
                    SizedBox(height: 12.h),
                    const CommonTextField(
                      hintText: "Enter Your City",
                      obscure: false,
                      type: TextInputType.name,
                      isTitle: true,
                      padding: false,
                      title: "Your City",
                    ),
                    SizedBox(height: 20.h),
                    CommonPrimaryButton(
                      ontap: () => customDialogAlert(
                        context,
                        AppAssets.doneSvg,
                        "Order Placed Successfully",
                        false,
                        "",
                      ),
                      title: "Order Place",
                      radius: 20.r,
                      height: 55.h,
                      phori: 0,
                      mainColor: AppColors.primaryColor,
                      textStyle: AppTextStyle.font16SemiBold.copyWith(
                        color: AppColors.whiteColor,
                      ),
                    )
                  ],
                ),
                true,
              ),
              child: Container(
                height: 50.h,
                width: 120.w,
                decoration: BoxDecoration(
                  color: AppColors.whiteColor,
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Center(
                  child: Text("Checkout", style: AppTextStyle.font14SemiBold),
                ),
              ),
            ),
          ],
        ).paddingSymmetric(horizontal: 20.w),
      ),
    );
  }
}
