import 'package:get/get.dart';
import'CartItem.dart';
class CartController extends GetxController {
  final RxList<CartItem> cartItems = <CartItem>[].obs;

  double calculateTotalAmount() {
    double totalPrice = 0.0;
    for (CartItem item in cartItems) {
      totalPrice += item.quantity * item.price;
    }
    return totalPrice;
  }

  void addToCart(String name, double price, int quantity) {
    CartItem newItem = CartItem(name: name, price: price, quantity: quantity);
    cartItems.add(newItem);
  }
}
