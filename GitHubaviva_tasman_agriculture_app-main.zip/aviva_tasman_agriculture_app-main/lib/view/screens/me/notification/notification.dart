// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../../../config/utility/dialog.dart';
import '../../../components/common_appbar.dart';
import '../../../helpers/app_assets.dart';
import '../../../helpers/app_colors.dart';
import '../../../helpers/app_text_style.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: ListView.builder(
        itemCount: 6,
        itemBuilder: (context, index) {
          return Column(
            children: [
              ListTile(
                onLongPress: () => customDialogAlert(
                  context,
                  AppAssets.deleteSvg,
                  "Do you want to delete ?",
                  false,
                  "",
                ),
                leading: CircleAvatar(
                  backgroundColor: AppColors.primaryColor,
                  child: Center(
                    child: SvgPicture.asset(
                      AppAssets.notificationSvg,
                      color: AppColors.whiteColor,
                      height: 24.h,
                    ),
                  ),
                ),
                title: Text("Alert", style: AppTextStyle.font14SemiBold),
                trailing: Text(
                  "8:40 PM",
                  style: AppTextStyle.font8.copyWith(
                    color: AppColors.primaryColor,
                  ),
                ),
                subtitle: Text(
                  "Please complete your profile",
                  style: AppTextStyle.font12.copyWith(
                    color: AppColors.greyColor,
                  ),
                ),
              ),
              const Divider().paddingSymmetric(horizontal: 12.w),
            ],
          );
        },
      ),
    );
  }
}
