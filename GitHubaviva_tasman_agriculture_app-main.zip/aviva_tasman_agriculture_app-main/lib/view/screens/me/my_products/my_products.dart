import 'package:flutter/material.dart';

import '../../../components/common_appbar.dart';
import '../../../widgets/my_products_const.dart';

class MyProductsScreen extends StatefulWidget {
  const MyProductsScreen({super.key});

  @override
  State<MyProductsScreen> createState() => _MyProductsScreenState();
}

class _MyProductsScreenState extends State<MyProductsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: ListView.builder(
        itemCount: 1,
        itemBuilder: (context, index) {
          return const MyProductsConst();
        },
      ),
    );
  }
}
