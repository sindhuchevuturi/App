import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../domain/state/tab_bar_state.dart';
import '../../../components/common_appbar.dart';
import '../../../helpers/app_colors.dart';
import '../../../helpers/app_text_style.dart';
import '../../../widgets/my_orders_const.dart';
import '../../../widgets/my_request_order_const.dart';

class MyOrdersScreen extends StatefulWidget {
  const MyOrdersScreen({super.key});

  @override
  State<MyOrdersScreen> createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> {
  var state = Get.put(TabBarState());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 12.h),
            Container(
              height: 60.h,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40.r),
                border: Border.all(
                  width: 0,
                  color: AppColors.blackColor,
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Obx(
                      () => GestureDetector(
                        onTap: () => state.activeFunction(),
                        child: Container(
                          height: 50.h,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40.r),
                            color: state.active.value
                                ? AppColors.primaryColor
                                : AppColors.transColor,
                          ),
                          child: Center(
                            child: Text(
                              "My Orders",
                              style: AppTextStyle.font16.copyWith(
                                color: state.active.value
                                    ? AppColors.whiteColor
                                    : AppColors.blackColor,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Obx(
                      () => GestureDetector(
                        onTap: () => state.unactiveFunction(),
                        child: Container(
                          height: 50.h,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40.r),
                            color: state.unactive.value
                                ? AppColors.primaryColor
                                : AppColors.transColor,
                          ),
                          child: Center(
                            child: Text(
                              "All Orders",
                              style: AppTextStyle.font16.copyWith(
                                color: state.unactive.value
                                    ? AppColors.whiteColor
                                    : AppColors.blackColor,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ).paddingSymmetric(horizontal: 4.w),
            ),
            SizedBox(height: 20.h),
            Obx(
              () => state.active.value
                  ? ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: 2,
                      itemBuilder: (context, index) {
                        return const MyOrdersConst();
                      },
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: 3,
                      itemBuilder: (context, index) {
                        return const OrderRequestConst();
                      },
                    ),
            ),
          ],
        ).paddingSymmetric(horizontal: 20.w),
      ),
    );
  }
}
