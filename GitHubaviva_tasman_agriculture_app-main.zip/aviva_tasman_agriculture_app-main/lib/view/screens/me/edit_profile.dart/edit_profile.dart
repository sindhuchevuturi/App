// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';

import '../../../components/common_appbar.dart';
import '../../../components/common_primary_button.dart';
import '../../../components/common_textfield.dart';
import '../../../helpers/app_assets.dart';
import '../../../helpers/app_colors.dart';
import '../../../helpers/app_text_style.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20.h),
            Stack(
              alignment: AlignmentDirectional.center,
              clipBehavior: Clip.none,
              children: [
                CircleAvatar(
                  radius: 64.r,
                  backgroundColor: AppColors.primaryColor,
                  child: CircleAvatar(
                    radius: 60.r,
                    backgroundColor: AppColors.transColor,
                    backgroundImage:
                        const NetworkImage(AppAssets.profileDemoImage),
                  ),
                ),
                Positioned(
                  right: -6,
                  bottom: 10,
                  child: GestureDetector(
                    onTap: () {},
                    child: CircleAvatar(
                      radius: 20.r,
                      backgroundColor: AppColors.primaryColor,
                      child: Center(
                        child: SvgPicture.asset(
                          AppAssets.cameraSvg,
                          height: 20.h,
                          color: AppColors.whiteColor,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20.h),
            const CommonTextField(
              hintText: "Aviva Tasman",
              obscure: false,
              type: TextInputType.name,
              isTitle: true,
              padding: true,
              title: "Enter Your Name",
            ),
            SizedBox(height: 20.h),
            CommonPrimaryButton(
              title: "Edit Now",
              height: 55.h,
              mainColor: AppColors.primaryColor,
              textStyle: AppTextStyle.font16SemiBold
                  .copyWith(color: AppColors.whiteColor),
              radius: 20.r,
            ),
          ],
        ),
      ),
    );
  }
}
