import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../components/common_appbar.dart';
import '../../../helpers/app_text_style.dart';

class SettingScreen extends StatefulWidget {
  const SettingScreen({super.key});

  @override
  State<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Currency", style: AppTextStyle.font16SemiBold),
                SizedBox(
                  width: 120.w,
                  height: 60.h,
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton(
                      hint: const Text("AUD"),
                      items: const [
                        DropdownMenuItem(
                          value: "AUD",
                          child: Text("AUD"),
                        ),
                        DropdownMenuItem(
                          value: "PHP",
                          child: Text("PHP"),
                        ),
                      ],
                      onChanged: (e) {},
                    ),
                  ),
                ),
              ],
            ),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Language", style: AppTextStyle.font16SemiBold),
                SizedBox(
                  width: 120.w,
                  height: 60.h,
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton(
                      hint: const Text("Australia"),
                      items: const [
                        DropdownMenuItem(
                          value: "Australia",
                          child: Text("Australia"),
                        ),
                        DropdownMenuItem(
                          value: "Philippines",
                          child: Text("Philippines"),
                        ),
                      ],
                      onChanged: (e) {},
                    ),
                  ),
                ),
              ],
            ),
          ],
        ).paddingSymmetric(horizontal: 12.w),
      ),
    );
  }
}
