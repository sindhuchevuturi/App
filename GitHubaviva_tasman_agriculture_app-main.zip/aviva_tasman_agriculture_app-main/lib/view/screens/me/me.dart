// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../config/routes/routes.dart';
import '../../helpers/app_assets.dart';
import '../../helpers/app_colors.dart';
import '../../helpers/app_text_style.dart';
import '../../widgets/me_const.dart';
import 'my_orders/my_orders.dart';

class MeScreen extends StatefulWidget {
  const MeScreen({super.key});

  @override
  State<MeScreen> createState() => _MeScreenState();
}

class _MeScreenState extends State<MeScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20.h),
            Container(
              height: 140.h,
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.primaryColor,
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundColor: AppColors.transColor,
                    radius: 50.r,
                    backgroundImage:
                        const NetworkImage(AppAssets.profileDemoImage),
                  ),
                  SizedBox(width: 20.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Aviva Tasman",
                        style: AppTextStyle.font22SemiBold.copyWith(
                          color: AppColors.whiteColor,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        "tasmanaviava@gmail.com",
                        style: AppTextStyle.font12.copyWith(
                          color: AppColors.whiteColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ).paddingSymmetric(horizontal: 20.w),
            ).paddingSymmetric(horizontal: 20.w, vertical: 12.h),
            SizedBox(height: 40.h),
            MeConst(
              svg: AppAssets.editSvg,
              title: "Edit Profile",
              onTap: () => Get.toNamed(routeEditProfileScreen),
            ),
            const Divider().paddingSymmetric(horizontal: 20.w),
            MeConst(
              svg: AppAssets.notificationSvg,
              title: "Notifications",
              onTap: () => Get.toNamed(routeNotificationScreen),
            ),
            const Divider().paddingSymmetric(horizontal: 20.w),
            MeConst(
              svg: AppAssets.orderSvg,
              title: "My Orders",
              onTap: () => Get.to(() => const MyOrdersScreen()),
            ),
            const Divider().paddingSymmetric(horizontal: 20.w),
            MeConst(
              svg: AppAssets.boxSvg,
              title: "My Products",
              onTap: () => Get.toNamed(routeMyProductsScreen),
            ),
            // const Divider().paddingSymmetric(horizontal: 20.w),
            // MeConst(
            //   svg: AppAssets.settingSvg,
            //   title: "Setting",
            //   onTap: () => Get.toNamed(routeSettingScreen),
            // ),
            const Divider().paddingSymmetric(horizontal: 20.w),
            MeConst(
              svg: AppAssets.profileSvg,
              title: "About Us",
              onTap: () {},
            ),
            const Divider().paddingSymmetric(horizontal: 20.w),
            MeConst(
              svg: AppAssets.contactusSvg,
              title: "Contact Us",
              onTap: () {},
            ),
            const Divider().paddingSymmetric(horizontal: 20.w),
            MeConst(
              svg: AppAssets.logoutSvg,
              title: "Logout",
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}
