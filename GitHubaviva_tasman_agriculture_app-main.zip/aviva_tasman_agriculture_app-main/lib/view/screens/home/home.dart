// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../../config/utility/bottom_sheet.dart';
import '../../components/common_textfield.dart';
import '../../helpers/app_assets.dart';
import '../../helpers/app_colors.dart';
import '../../helpers/app_text_style.dart';
import '../../widgets/product_const.dart';
import '../search/search.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(
                  AppAssets.mainLogo,
                  height: 80.h,
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => customBottomSheet(
                          context,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Select Language",
                                style: AppTextStyle.font16SemiBold,
                              ),
                              SizedBox(height: 12.h),
                              DropdownButton(
                                isExpanded: true,
                                hint: const Text("Australia"),
                                items: const [
                                  DropdownMenuItem(
                                    value: "Australia",
                                    child: Text("Australia"),
                                  ),
                                  DropdownMenuItem(
                                    value: "Philippines",
                                    child: Text("Philippines"),
                                  ),
                                ],
                                onChanged: (e) {},
                              ),
                            ],
                          ),
                          false),
                      child: SvgPicture.asset(
                        AppAssets.languageSvg,
                        height: 26.h,
                        color: AppColors.primaryColor,
                      ),
                    ),
                    SizedBox(width: 20.w),
                    GestureDetector(
                      onTap: () => customBottomSheet(
                          context,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Select Currency",
                                style: AppTextStyle.font16SemiBold,
                              ),
                              SizedBox(height: 12.h),
                              DropdownButton(
                                isExpanded: true,
                                hint: const Text("AUD"),
                                items: const [
                                  DropdownMenuItem(
                                    value: "AUD",
                                    child: Text("AUD"),
                                  ),
                                  DropdownMenuItem(
                                    value: "PHP",
                                    child: Text("PHP"),
                                  ),
                                ],
                                onChanged: (e) {},
                              ),
                            ],
                          ),
                          false),
                      child: SvgPicture.asset(
                        AppAssets.currencySvg,
                        height: 26.h,
                        color: AppColors.primaryColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20.h),
            CommonTextField(
              hintText: "Search",
              obscure: false,
              type: TextInputType.text,
              isTitle: false,
              padding: false,
              onSubmit: (e) {
                Get.to(() => const SearchScreen());
              },
            ),
            SizedBox(height: 40.h),
            Text("All Products", style: AppTextStyle.font18Bold),
            SizedBox(height: 20.h),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 2,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.75,
              ),
              itemBuilder: (context, index) {
                return const ProductConst();
              },
            ),
            SizedBox(height: 20.h),
            Text("Popular", style: AppTextStyle.font18Bold),
            SizedBox(height: 20.h),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 3,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.75,
              ),
              itemBuilder: (context, index) {
                return const ProductConst();
              },
            ),
          ],
        ).paddingSymmetric(horizontal: 20.w),
      ),
    );
  }
}
