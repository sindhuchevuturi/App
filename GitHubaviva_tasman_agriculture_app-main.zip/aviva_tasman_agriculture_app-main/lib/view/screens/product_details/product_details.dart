// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../../config/utility/dialog.dart';
import '../../../domain/state/incr_decr_state.dart';
import '../../components/common_appbar.dart';
import '../../components/common_primary_button.dart';
import '../../helpers/app_assets.dart';
import '../../helpers/app_colors.dart';
import '../../helpers/app_text_style.dart';

// Define a simple data model for CartItem
class CartItem {
  final String name;
  final double price;
  final int quantity;

  CartItem({
    required this.name,
    required this.price,
    required this.quantity,
  });
}
var state = Get.find<IncrAndDecrState>();

class ProductDetailsScreen extends StatefulWidget {
  const ProductDetailsScreen({super.key});

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  var state = Get.put(IncrAndDecrState());

  // List to store items added to the cart
  List<CartItem> cartItems = [];

  // Function to add an item to the cart
  void addToCart(String name, double price, int quantity) {

    print("Adding to cart: $name, $price, $quantity");
    CartItem newItem = CartItem(name: name, price: price, quantity: quantity);
    setState(() {
      cartItems.add(newItem);
      print("Cart Items: $cartItems");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar(context, []),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 300.h,
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.primaryColor,
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(80.r),
                  topLeft: Radius.circular(80.r),
                ),
              ),
              child: Center(
                child: Image.network(AppAssets.productDemoImage),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Food Package", style: AppTextStyle.font20SemiBold),
                  ],
                ),
                SizedBox(height: 8.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("₱ 3000 PHP", style: AppTextStyle.font14),
                    Row(
                      children: [
                        Text("4.5", style: AppTextStyle.font12),
                        SizedBox(width: 4.w),
                        SvgPicture.asset(
                          AppAssets.starSvg,
                          color: AppColors.yellowColor,
                          height: 20.h,
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 8.h),
                const Divider(),
                SizedBox(height: 8.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Quantity", style: AppTextStyle.font16SemiBold),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => state.decrement(),
                          child: Container(
                            height: 40.h,
                            width: 60.w,
                            decoration: BoxDecoration(
                              color: AppColors.primaryColor,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20.r),
                                bottomLeft: Radius.circular(20.r),
                                topRight: Radius.circular(8.r),
                                bottomRight: Radius.circular(8.r),
                              ),
                            ),
                            child: Center(
                              child: Text(
                                "–",
                                style: AppTextStyle.font20Bold.copyWith(
                                  color: AppColors.whiteColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 12.w),
                        Obx(
                              () => Text(
                            state.quantity.value.toString(),
                            textAlign: TextAlign.center,
                            style: AppTextStyle.font16Bold.copyWith(
                              color: AppColors.primaryColor,
                            ),
                          ),
                        ),
                        SizedBox(width: 12.w),
                        GestureDetector(
                          onTap: () => state.increment(),
                          child: Container(
                            height: 40.h,
                            width: 60.w,
                            decoration: BoxDecoration(
                              color: AppColors.primaryColor,
                              borderRadius: BorderRadius.only(
                                topRight: Radius.circular(20.r),
                                bottomRight: Radius.circular(20.r),
                                topLeft: Radius.circular(8.r),
                                bottomLeft: Radius.circular(8.r),
                              ),
                            ),
                            child: Center(
                              child: Text(
                                "+",
                                style: AppTextStyle.font20Bold.copyWith(
                                  color: AppColors.whiteColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 8.h),
                const Divider(),
                SizedBox(height: 8.h),
                Text(
                  "Consists of \nRegular Whole Chicken 3 PCS \nPork Liempo Cut 1 KG \nPinakbet Mix 7KG \nRice Anak Maharlika 25KG \nGarlic 1KG \nWhite onions 1KG \nSayote 1KG \nFresh White Eggs Medium (30s) 30 Pieces \nBanana Lakatan 2KG",
                  style: AppTextStyle.font12.copyWith(
                    color: AppColors.greyColor,
                  ),
                ),
              ],
            ).paddingSymmetric(horizontal: 20.w),
          ],
        ),
      ),
      bottomNavigationBar: CommonPrimaryButton(
        ontap: () {
          // Call the addToCart function when the button is tapped
          addToCart("Food Package", 3000, state.quantity.value);
          customDialogAlert(
            context,
            AppAssets.doneSvg,
            "Product Added to Cart Successfully",
            false,
            "",
          );
        },
        title: "Add to Cart",
        height: 60.h,
        radius: 20.r,
        mainColor: AppColors.primaryColor,
        textStyle: AppTextStyle.font16SemiBold.copyWith(
          color: AppColors.whiteColor,
        ),
      ),
    );
  }
}
