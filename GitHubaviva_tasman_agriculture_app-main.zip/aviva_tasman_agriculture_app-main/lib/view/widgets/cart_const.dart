import 'package:aviva_tasman_agri/view/screens/cart/CartItem.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../helpers/app_assets.dart';
import '../helpers/app_colors.dart';
import '../helpers/app_text_style.dart';

class CartConst extends StatelessWidget {
  final CartItem cartItem;

  const CartConst({
    Key? key,
    required this.cartItem,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100.h,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.r),
        color: AppColors.whiteColor,
        boxShadow: const [
          BoxShadow(
            color: AppColors.greyColor,
            blurRadius: 4,
            spreadRadius: 0.2,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Image.network(AppAssets.productDemoImage, height: 60.h),
              SizedBox(width: 20.w),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(cartItem.name, style: AppTextStyle.font16SemiBold),
                  SizedBox(height: 4.h),
                  Text("₱ ${cartItem.price} PHP", style: AppTextStyle.font14),
                ],
              ),
            ],
          ),
          Row(
            children: [
              CircleAvatar(
                backgroundColor: AppColors.primaryColor,
                radius: 16.r,
                child: Center(
                  child: Icon(
                    Icons.add,
                    size: 16.sp,
                    color: AppColors.whiteColor,
                  ),
                ),
              ),
              SizedBox(width: 8.w),
              Text(
                cartItem.quantity.toString(),
                style: AppTextStyle.font12SemiBold.copyWith(
                  color: AppColors.primaryColor,
                ),
              ),
              SizedBox(width: 8.w),
              CircleAvatar(
                backgroundColor: AppColors.primaryColor,
                radius: 16.r,
                child: GestureDetector(
                  onTap: () {
    // Implement logic to increase quantity for the corresponding cart item
    },
                child: Center(
                  child: Icon(
                    Icons.remove,
                    size: 14.sp,
                    color: AppColors.whiteColor,
                  ),
                ),
              ),
              ) ],
          ),
        ],
      ).paddingSymmetric(horizontal: 12.w),
    ).paddingSymmetric(vertical: 12.h);
  }
}
