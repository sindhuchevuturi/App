// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../helpers/app_assets.dart';
import '../helpers/app_colors.dart';
import '../helpers/app_text_style.dart';
import '../screens/product_details/product_details.dart';

class FavouriteConst extends StatelessWidget {
  const FavouriteConst({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.to(() => const ProductDetailsScreen()),
      child: Container(
        height: 100.h,
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.circular(20.r),
          boxShadow: const [
            BoxShadow(
              color: AppColors.greyColor,
              blurRadius: 4,
              spreadRadius: 0.2,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Image.network(AppAssets.productDemoImage, height: 60.h),
                SizedBox(width: 20.w),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("HP EliteBook", style: AppTextStyle.font18SemiBold),
                    SizedBox(height: 4.h),
                    Text("Rs.25000", style: AppTextStyle.font14),
                  ],
                ),
              ],
            ),
            SvgPicture.asset(
              AppAssets.heartfullSvg,
              color: AppColors.redColor,
            ),
          ],
        ).paddingSymmetric(horizontal: 12.w),
      ).paddingSymmetric(vertical: 12.h),
    );
  }
}
