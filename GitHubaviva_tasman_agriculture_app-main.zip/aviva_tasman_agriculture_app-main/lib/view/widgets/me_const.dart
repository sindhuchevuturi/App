// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../helpers/app_colors.dart';
import '../helpers/app_text_style.dart';

class MeConst extends StatelessWidget {
  final String svg;
  final String title;
  final void Function() onTap;
  const MeConst({
    required this.svg,
    required this.title,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                height: 45.h,
                width: 45.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.r),
                  color: AppColors.primaryColor,
                ),
                child: Center(
                  child: SvgPicture.asset(
                    svg,
                    color: AppColors.whiteColor,
                    height: 24.h,
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              Text(title, style: AppTextStyle.font14),
            ],
          ),
          const Icon(Icons.arrow_forward),
        ],
      ).paddingSymmetric(horizontal: 20.w, vertical: 12.h),
    );
  }
}
