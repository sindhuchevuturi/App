import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../helpers/app_assets.dart';
import '../helpers/app_colors.dart';
import '../helpers/app_text_style.dart';
import '../screens/product_details/product_details.dart';

class ProductConst extends StatelessWidget {
  const ProductConst({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.to(() => const ProductDetailsScreen()),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.circular(20.r),
          boxShadow: const [
            BoxShadow(
              color: AppColors.greyColor,
              blurRadius: 4,
              spreadRadius: 0.2,
            ),
          ],
        ),
        child: Column(
          children: [
            SizedBox(height: 12.h),
            Image.network(
              AppAssets.productDemoImage,
              height: 100.h,
            ),
            SizedBox(height: 12.h),
            Text("Food Package", style: AppTextStyle.font18SemiBold),
            SizedBox(height: 4.h),
            Text(
              "Contains Protein, Fiber and Carbs",
              style: AppTextStyle.font12.copyWith(
                color: AppColors.greyColor,
              ),
            ),
            SizedBox(height: 12.h),
            Text(
              "₱ 3000 PHP",
              style: AppTextStyle.font14SemiBold.copyWith(
                color: AppColors.primaryColor,
              ),
            ),
          ],
        ),
      ).paddingAll(8.h),
    );
  }
}
