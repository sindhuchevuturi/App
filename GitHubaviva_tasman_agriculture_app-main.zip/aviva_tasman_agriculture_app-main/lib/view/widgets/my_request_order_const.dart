import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../components/common_primary_button.dart';
import '../helpers/app_assets.dart';
import '../helpers/app_colors.dart';
import '../helpers/app_text_style.dart';

class OrderRequestConst extends StatelessWidget {
  const OrderRequestConst({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 360.h,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.r),
        color: AppColors.whiteColor,
        boxShadow: const [
          BoxShadow(
            color: AppColors.greyColor,
            blurRadius: 4,
            spreadRadius: 0.2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Image.network(
                    AppAssets.productDemoImage,
                    height: 60.h,
                  ),
                  SizedBox(width: 20.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Food Package",
                        style: AppTextStyle.font16SemiBold,
                      ),
                      Text(
                        "x3",
                        style: AppTextStyle.font12.copyWith(
                          color: AppColors.greyColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "20-01-24",
                    style: AppTextStyle.font12.copyWith(
                      color: AppColors.greyColor,
                    ),
                  ),
                  Text(
                    "8:00 PM",
                    style: AppTextStyle.font12.copyWith(
                      color: AppColors.greyColor,
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 8.h),
          const Divider(),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Order Id",
                style: AppTextStyle.font12SemiBold,
              ),
              Text(
                "#099870",
                style: AppTextStyle.font12.copyWith(
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Total Price",
                style: AppTextStyle.font12SemiBold,
              ),
              Text(
                "₱ 3000 PHP",
                style: AppTextStyle.font12.copyWith(
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Name",
                style: AppTextStyle.font12SemiBold,
              ),
              Text(
                "Ali Hassan",
                style: AppTextStyle.font12.copyWith(
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Email",
                style: AppTextStyle.font12SemiBold,
              ),
              Text(
                "alihassan@gmail.com",
                style: AppTextStyle.font12.copyWith(
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Address",
                style: AppTextStyle.font12SemiBold,
              ),
              Text(
                "Malik Road, Faisalabad",
                style: AppTextStyle.font12.copyWith(
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Status",
                style: AppTextStyle.font12SemiBold,
              ),
              Text(
                "Pending",
                style: AppTextStyle.font12.copyWith(
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          const Divider(),
          SizedBox(height: 8.h),
          Row(
            children: [
              Expanded(
                child: CommonPrimaryButton(
                  title: "Approve",
                  height: 40.h,
                  mainColor: AppColors.primaryColor,
                  phori: 0,
                  pverti: 8.h,
                  textStyle: AppTextStyle.font14SemiBold.copyWith(
                    color: AppColors.whiteColor,
                  ),
                  radius: 20.r,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: CommonPrimaryButton(
                  title: "Delivered",
                  height: 40.h,
                  mainColor: AppColors.transColor,
                  phori: 0,
                  pverti: 8.h,
                  borderColor: AppColors.primaryColor,
                  textStyle: AppTextStyle.font14SemiBold.copyWith(
                    color: AppColors.primaryColor,
                  ),
                  radius: 20.r,
                ),
              ),
            ],
          ),
        ],
      ).paddingAll(12.h),
    ).paddingSymmetric(vertical: 12.h);
  }
}
