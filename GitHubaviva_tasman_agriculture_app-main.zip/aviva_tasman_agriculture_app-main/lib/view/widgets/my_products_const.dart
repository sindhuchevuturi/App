// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../../../config/utility/bottom_sheet.dart';
import '../../../../config/utility/dialog.dart';
import '../components/common_primary_button.dart';
import '../components/common_textfield.dart';
import '../helpers/app_assets.dart';
import '../helpers/app_colors.dart';
import '../helpers/app_text_style.dart';
import '../screens/product_details/product_details.dart';

class MyProductsConst extends StatelessWidget {
  const MyProductsConst({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.to(() => const ProductDetailsScreen()),
      child: Container(
        height: 100.h,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.r),
          color: AppColors.whiteColor,
          boxShadow: const [
            BoxShadow(
              color: AppColors.greyColor,
              blurRadius: 4,
              spreadRadius: 0.2,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Image.network(
                  AppAssets.productDemoImage,
                  height: 60.h,
                ),
                SizedBox(width: 20.w),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Food Package",
                      style: AppTextStyle.font16SemiBold,
                    ),
                    SizedBox(height: 4.h),
                    Text("₱ 3000 PHP", style: AppTextStyle.font14),
                    SizedBox(height: 4.h),
                    Row(
                      children: [
                        Text("4.5", style: AppTextStyle.font12),
                        SizedBox(width: 4.w),
                        SvgPicture.asset(
                          AppAssets.starSvg,
                          color: AppColors.yellowColor,
                          height: 18.h,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            GestureDetector(
              onTap: () => customBottomSheet(
                context,
                Column(
                  children: [
                    const CommonTextField(
                      hintText: "Food Package 2",
                      obscure: false,
                      type: TextInputType.name,
                      isTitle: true,
                      padding: false,
                      title: "Product Name",
                    ),
                    SizedBox(height: 12.h),
                    const CommonTextField(
                      hintText: "The package consists of..",
                      obscure: false,
                      type: TextInputType.name,
                      isTitle: true,
                      padding: false,
                      title: "Product Description",
                    ),
                    SizedBox(height: 20.h),
                    const CommonTextField(
                      hintText: "₱ 3000 PHP",
                      obscure: false,
                      type: TextInputType.number,
                      isTitle: true,
                      padding: false,
                      title: "Product Price",
                    ),
                    SizedBox(height: 30.h),
                    CommonPrimaryButton(
                      ontap: () => customDialogAlert(
                        context,
                        AppAssets.doneSvg,
                        "Your Product Edit Successfully",
                        false,
                        "",
                      ),
                      title: "Edit Now",
                      height: 55.h,
                      mainColor: AppColors.primaryColor,
                      phori: 0,
                      textStyle: AppTextStyle.font16SemiBold.copyWith(
                        color: AppColors.whiteColor,
                      ),
                      radius: 20,
                    ),
                    CommonPrimaryButton(
                      ontap: () => customDialogAlert(
                        context,
                        AppAssets.deleteSvg,
                        "Do you want to delete ?",
                        false,
                        "",
                      ),
                      title: "Delete Now",
                      height: 55.h,
                      mainColor: AppColors.redColor,
                      phori: 0,
                      textStyle: AppTextStyle.font16SemiBold.copyWith(
                        color: AppColors.whiteColor,
                      ),
                      radius: 20,
                    ),
                    CommonPrimaryButton(
                      ontap: () => Get.back(),
                      title: "Cancel",
                      height: 55.h,
                      mainColor: AppColors.transColor,
                      phori: 0,
                      textStyle: AppTextStyle.font16SemiBold.copyWith(
                        color: AppColors.primaryColor,
                      ),
                      radius: 20,
                      borderColor: AppColors.primaryColor,
                    ),
                  ],
                ),
                true,
              ),
              child: SvgPicture.asset(
                AppAssets.infoSvg,
                color: AppColors.primaryColor,
              ).paddingSymmetric(horizontal: 8.w),
            ),
          ],
        ).paddingSymmetric(horizontal: 12.w),
      ).paddingSymmetric(horizontal: 20.w, vertical: 12.h),
    );
  }
}
