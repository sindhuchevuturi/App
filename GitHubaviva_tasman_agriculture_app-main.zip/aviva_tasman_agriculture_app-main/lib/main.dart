import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'domain/state/incr_decr_state.dart';
import 'config/routes/routes.dart';
import 'config/theme/theme.dart';

void main() {
  runApp(const AvivaTasman());
}

class AvivaTasman extends StatelessWidget {
  const AvivaTasman({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      builder: (context, _) {
        ScreenUtil.init(
          context,
          designSize: const Size(393, 852),
        );
        return GetMaterialApp(
          theme: AppThemeData.mainAppTheme(context),
          debugShowCheckedModeBanner: false,
          getPages: Routes.routes,
          initialRoute: routeSplashScreen,
          defaultTransition: Transition.leftToRightWithFade,
          transitionDuration: const Duration(milliseconds: 300),
          initialBinding: BindingsBuilder(() {
            Get.put(IncrAndDecrState(), permanent: true);
          }),
        );
      },
    );
  }
}
