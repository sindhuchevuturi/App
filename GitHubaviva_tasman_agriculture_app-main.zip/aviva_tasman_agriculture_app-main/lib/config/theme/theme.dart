import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../view/helpers/app_colors.dart';

class AppThemeData {
  static ThemeData mainAppTheme(BuildContext context) {
    return ThemeData(
      scaffoldBackgroundColor: AppColors.whiteColor,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.whiteColor,
        elevation: 0,
      ),
      textTheme: GoogleFonts.robotoTextTheme(Theme.of(context).textTheme).apply(
        bodyColor: AppColors.blackColor,
      ),
    );
  }
}
