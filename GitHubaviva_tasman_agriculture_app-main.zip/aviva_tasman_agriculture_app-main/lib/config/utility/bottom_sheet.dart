import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

void customBottomSheet(BuildContext context, Widget content, bool isScroll) {
  showModalBottomSheet(
    context: context,
    builder: (context) {
      return SizedBox(
        width: double.infinity,
        child: isScroll
            ? SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 20.h),
                    content,
                    SizedBox(height: 20.h),
                  ],
                ).paddingSymmetric(horizontal: 20.w),
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 20.h),
                  content,
                  SizedBox(height: 20.h),
                ],
              ).paddingSymmetric(horizontal: 20.w),
      );
    },
  );
}
