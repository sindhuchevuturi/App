// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../view/components/common_primary_button.dart';
import '../../view/helpers/app_colors.dart';
import '../../view/helpers/app_text_style.dart';

void customDialogAlert(
  BuildContext context,
  String svg,
  String message,
  bool coupleButton,
  String buttonTitle,
) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 20.h),
            SvgPicture.asset(
              svg,
              height: 80.h,
              color: AppColors.primaryColor,
            ),
            SizedBox(height: 20.h),
            Text(
              message,
              style: AppTextStyle.font14SemiBold,
            ),
            SizedBox(height: 20.h),
            coupleButton
                ? Row(
                    children: [
                      CommonPrimaryButton(
                        ontap: () => Get.back(),
                        title: "Ok",
                        height: 40.h,
                        pverti: 0,
                        phori: 0,
                        radius: 12.r,
                        mainColor: AppColors.primaryColor,
                        textStyle: AppTextStyle.font14SemiBold.copyWith(
                          color: AppColors.whiteColor,
                        ),
                        width: 120.w,
                      ),
                      SizedBox(width: 12.w),
                      CommonPrimaryButton(
                        ontap: () => Get.back(),
                        title: buttonTitle,
                        height: 40.h,
                        pverti: 0,
                        phori: 0,
                        radius: 12.r,
                        mainColor: AppColors.primaryColor,
                        textStyle: AppTextStyle.font14SemiBold.copyWith(
                          color: AppColors.whiteColor,
                        ),
                        width: 120.w,
                      ),
                    ],
                  )
                : CommonPrimaryButton(
                    ontap: () => Get.back(),
                    title: "Ok",
                    height: 40.h,
                    pverti: 0,
                    phori: 0,
                    radius: 12.r,
                    mainColor: AppColors.primaryColor,
                    textStyle: AppTextStyle.font14SemiBold.copyWith(
                      color: AppColors.whiteColor,
                    ),
                    width: 120.w,
                  ),
          ],
        ),
      );
    },
  );
}
