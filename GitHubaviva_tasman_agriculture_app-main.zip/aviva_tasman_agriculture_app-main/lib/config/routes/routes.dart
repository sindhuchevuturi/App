import 'package:get/get.dart';

import '../../view/screens/auth/login/login.dart';
import '../../view/screens/auth/reset_password/reset_password.dart';
import '../../view/screens/auth/signup/signup.dart';
import '../../view/screens/bottom_nav/bottom_nav.dart';
import '../../view/screens/me/edit_profile.dart/edit_profile.dart';
import '../../view/screens/me/my_orders/my_orders.dart';
import '../../view/screens/me/my_products/my_products.dart';
import '../../view/screens/me/notification/notification.dart';
import '../../view/screens/me/settings/settings.dart';
import '../../view/screens/splash/splash.dart';

const routeSplashScreen = "/SplashScreen";
const routeLoginScreen = "/LoginScreen";
const routeSignupScreen = "/SignupScreen";
const routeResetPasswordScreen = "/ResetPasswordScreen";
const routeBottomNavScreen = "/BottomNavScreen";
const routeEditProfileScreen = "/EditProfileScreen";
const routeNotificationScreen = "/NotificationScreen";
const routeMyOrdersScreen = "/MyOrdersScreen";
const routeMyProductsScreen = "/MyProductsScreen";
const routeSettingScreen = "/SettingScreen";

class Routes {
  static final routes = [
    GetPage(
      name: routeSettingScreen,
      page: () => const SettingScreen(),
    ),
    GetPage(
      name: routeMyProductsScreen,
      page: () => const MyProductsScreen(),
    ),
    GetPage(
      name: routeMyOrdersScreen,
      page: () => const MyOrdersScreen(),
    ),
    GetPage(
      name: routeNotificationScreen,
      page: () => const NotificationScreen(),
    ),
    GetPage(
      name: routeEditProfileScreen,
      page: () => const EditProfileScreen(),
    ),
    GetPage(
      name: routeBottomNavScreen,
      page: () => const BottomNavScreen(),
    ),
    GetPage(
      name: routeResetPasswordScreen,
      page: () => const ResetPasswordScreen(),
    ),
    GetPage(
      name: routeSignupScreen,
      page: () => const SignupScreen(),
    ),
    GetPage(
      name: routeLoginScreen,
      page: () => const LoginScreen(),
    ),
    GetPage(
      name: routeSplashScreen,
      page: () => const SplashScreen(),
    ),
  ];
}
