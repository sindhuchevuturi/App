import 'package:get/get.dart';
import 'package:flutter/material.dart';

import '../../view/screens/add/add.dart';
import '../../view/screens/cart/cart.dart';
import '../../view/screens/home/home.dart';
import '../../view/screens/me/me.dart';

class BottomNavState extends GetxController {
  // Use RxInt for reactive integers
  RxInt index = 0.obs;

  // Use late initialization for better performance
  late RxList<Widget> pages;

  @override
  void onInit() {
    // Initialize the pages list in the onInit lifecycle method
    pages = [
      HomeScreen(),
      AddScreen(),
      CartScreen(),
      MeScreen(),
    ].obs;

    super.onInit();
  }

  // Use a more descriptive method name
  void changePageIndex(int newIndex) {
    index.value = newIndex;

  }
}
