import 'package:get/get.dart';

class IncrAndDecrState extends GetxController {
  RxInt quantity = 1.obs;

  increment() {
    if (quantity.value > 0) {
      quantity.value++;
    }
  }

  decrement() {
    if (quantity.value > 1) {
      quantity.value--;
    }
  }
}
