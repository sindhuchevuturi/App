import 'package:get/get.dart';

class TextFieldState extends GetxController {
  RxBool obscure = false.obs;

  changer() {
    obscure.value = !obscure.value;
  }
}
