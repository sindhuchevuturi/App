import 'package:get/get.dart';

class TabBarState extends GetxController {
  RxBool active = true.obs;
  RxBool unactive = false.obs;

  activeFunction() {
    active.value = true;
    unactive.value = false;
  }

  unactiveFunction() {
    active.value = false;
    unactive.value = true;
  }
}
